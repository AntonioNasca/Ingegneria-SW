import java.io.*;

public class Test
{
    private Pagamenti p=new Pagamenti();


    public void initLista()
    {
      p.svuota();;
      p.inserisci(200);
      p.inserisci(100);
      p.inserisci(300);


    }

    public void testSommaValori()
    {
       initLista();
       if(p.calcolaSomma()==600f)
       System.out.println("OK, contaSomma funziona");
       else
       System.out.println("Attenzione, contaSomma non funziona");


    }

    public void testLeggiFile()
    {
       p.svuota();
       try
       {
           p.LeggiFile("txtFile", "Pagamenti.txt");
           System.out.println("OK, test leggiFile funziona");
       }

       catch(IOException e)
       {
        System.out.println("Attenzione, LeggiFile non funziona");

       }

    }

    public void testMaxValore()
    {
       initLista();
       p.calcolaMax();
       if(p.calcolaMax()==300)
       System.out.println("OK, il calcolaMax funziona");
       else
       System.out.println("Attenzione, il max non funziona");


    }

    public void testMinValore()
    {
       initLista();
       p.calcolaMin();
       if(p.calcolaMin()==100)
       System.out.println("OK, il calcolaMin funziona");
       else
       System.out.println("Attenzione, il Min non funziona");


    }

    public void testContaElementi()
    {
       initLista();
       p.contaElementi();
       if(p.contaElementi()==3)
       System.out.println("OK, il contaElementi funziona");
       else
       System.out.println("Attenzione, il ContaElementi non funziona");


    }

  public static void main(String[] args) 
  {
     Test t1=new Test();
     t1.testContaElementi();
     t1.testLeggiFile();
     t1.testMaxValore();
     t1.testMinValore();
     t1.testSommaValori();
  }

}