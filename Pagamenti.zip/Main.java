import java.io.IOException;

public class Main
{
    public static void main(String[] args) 
   {
        Pagamenti p=new Pagamenti();
        
        try
        {
           p.LeggiFile("txtFile","Pagamenti.txt");
           System.out.println("Inizio esecuzione");
           System.out.println("Somma="+p.calcolaSomma());
           System.out.println("Massimo="+p.calcolaMax());
           System.out.println("Minimo="+p.calcolaMin());
           System.out.println("Totale elementi="+p.contaElementi());
        }

        catch(IOException e)
        {
           System.out.println("Fle non trovato");

        }

        
   }


}